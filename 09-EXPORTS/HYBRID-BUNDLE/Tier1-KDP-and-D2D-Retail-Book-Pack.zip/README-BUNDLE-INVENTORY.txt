================================================================================
THE SMALL BUSINESS AI AUTOMATION OPERATING SYSTEM (2026 ENTERPRISE EDITION)
FINAL PRODUCTION PACKAGE INVENTORY: Tier 1 — Amazon KDP & Draft2Digital Retail Book Pack ($9.99 Digital / $16.99 Print)
================================================================================

INCLUDED FILES IN THIS ARCHIVE:
  - 01-Kindle-and-D2D-EPUB3/the-smallbiz-ai-automation-os.epub (385,064 bytes)
  - 02-KDP-Print-6x9-Interior/the-smallbiz-ai-automation-os-kdp-paperback-6x9.pdf (6,619,841 bytes)
  - 03-Retail-Covers/ebook-cover-kdp-kindle.png (1,322,001 bytes)
  - 03-Retail-Covers/kdp-paperback-full-wrap-cover.pdf (306,842 bytes)
  - 03-Retail-Covers/kdp-paperback-full-wrap-cover.png (1,221,176 bytes)
  - 04-Publishing-Runbooks/marketplace-listings-and-bd-launch-runbook.md (27,981 bytes)
  - 04-Publishing-Runbooks/COVER-DESIGN-AND-PACKAGING-SPEC.md (14,886 bytes)

--------------------------------------------------------------------------------
QUICK-START LAUNCH INSTRUCTIONS:
1. Extract this .zip archive to a local folder on your workstation.
2. Open PDF editions in Adobe Acrobat Reader, Microsoft Edge, or GoodNotes.
3. Double-click `smallbiz-automation-os-app.html` (if included in your tier)
   to launch the 100% offline SaaS-Lite Web Companion Suite in any browser.
   (Tier 3 & Tier 4 buyers: enter Pro Key `SMALLBIZ-OS-PRO-2026`).
4. Double-click `design-customizer-studio.html` (Tier 3 & Tier 4) to customize
   and export high-resolution PNG/SVG covers, SOP binder covers, and social cards.
================================================================================